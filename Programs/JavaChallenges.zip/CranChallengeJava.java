import java.util.Scanner;
import java.lang.String;

public class CranChallengeJava {
    public static void main(String[] args) {
        Scanner input2 = new Scanner(System.in);
        System.out.println("Which challenge (number): ");
        int chal = input2.nextInt();
        switch (chal) {
            case 1:
                chal1();
                break;
            case 2:
                chal2();
                break;
            case 3:
                chal3();
                break;
            case 4:
                chal4();
                break;
            case 5:
                chal5();
                break;
            case 6:
                chal6();
                break;
            default:
                System.out.println("It no exist.");
        }
    }
    public static void chal1(){
        Scanner input = new Scanner(System.in);
        System.out.println("? ");
        System.out.println("An integer to test: ");
        int inp = input.nextInt();

        if (java.lang.Math.sqrt(inp) % 1 == 0) {
            System.out.print("true ");
        } else {
            System.out.print("false ");
        }
        if (java.lang.Math.cbrt(inp) % 1 == 0) {
            System.out.print("true");
        } else {
            System.out.print("false");
        }
    }
    public static void chal2(){
        Scanner input = new Scanner(System.in);
        System.out.println("? ");
        System.out.println("Num of people: ");
        int people = input.nextInt();

        double pop = popGet(people);
        //System.out.println(pop);
        double pizza = java.lang.Math.ceil(people / 4);
        //System.out.println(pizza);
        double coupon = java.lang.Math.ceil(pizza / 2);
        //System.out.println(coupon);
        if (pop == coupon) {
            System.out.println(coupon + 1);
        } else if (pop < coupon) {
            System.out.println(coupon);
        } else {
            System.out.println(pop);
        }
    }
    public static void chal3(){
        Scanner input = new Scanner(System.in);
        System.out.println("? ");
        System.out.println("Height: ");
        double height = input.nextDouble();
        System.out.println("Width: ");
        Scanner input3 = new Scanner(System.in);
        double width = input3.nextDouble();
        System.out.println("Length: ");
        Scanner input4 = new Scanner(System.in);
        double length = input4.nextDouble();

        //double area = length * height + (width*height)/2;
        double c = Math.sqrt(Math.pow(height,2)+Math.pow(width/2.0,2));
        double area = 2*(c*length);
        //System.out.println(area);
        //System.out.println(width/2+" "+width/2.0);
        double bundle = Math.floor(area/100.0)*3.0;
        double modArea = area % 100;
        if(modArea >= 1 && modArea<= 32){
            bundle += 1;
        }
        else if(modArea >= 33 && modArea<= 65){
            bundle += 2;
        }
        else if(modArea >= 66 && modArea<= 99){
            bundle += 3;
        }
        System.out.println(Math.round(bundle));
    }
    public static void chal4(){
        Scanner input4 = new Scanner(System.in);
        System.out.println("? ");
        System.out.println("Enter a string: ");
        String strg = input4.nextLine();

        //strg = "zz" + strg + "zz";

        strg = strg.replaceAll("[\\.\\?!; ,]","");
        strg = strg.replaceAll("T", "t");
        //System.out.println(strg);

        int total = 0;
        Character[] vowels ={'a', 'e', 'i', 'o', 'u'};

        int the = strg.indexOf("the");
        //System.out.println(vowels);
        //String[] splitString = (strg.split(the+1));

        while (the != -1) {
            if (the > 0) {
                for (int i =0; i<5; i++) {
                    //if (strg.charAt(the - 1) == vowels[0] || strg.charAt(the - 1) == vowels[1] || strg.charAt(the - 1) == vowels[2] || strg.charAt(the - 1) == vowels[3] || strg.charAt(the - 1) == vowels[4]) {
                    if (strg.charAt(the - 1) == vowels[i]) {
                        total += 1;
                    }
                }
            }
            if (the+3 < strg.length()) {
                for (int i = 0; i < 5; i++) {
                    //if (strg.charAt(the + 3) == vowels[0] || strg.charAt(the + 3) == vowels[1] || strg.charAt(the + 3) == vowels[2] || strg.charAt(the + 3) == vowels[3] || strg.charAt(the + 3) == vowels[4]) {
                    if (strg.charAt(the + 3) == vowels[i]) {
                        total += 1;
                    }
                }
            }
            //System.out.println(total);
            strg = strg.replaceFirst("the", "xxx");
            //System.out.println(strg);
            the = strg.indexOf("the");
        }
        System.out.println(total);
    }
    public static void chal5(){
        Scanner input = new Scanner(System.in);
        System.out.println("? ");
        System.out.println("One num: ");
        int num = input.nextInt();
        Scanner input5 = new Scanner(System.in);
        System.out.println("Another num: ");
        int num2 = input5.nextInt();
        int total = 0;

        while (num >= 1){
            System.out.printf("%7d",num);
            if (num % 2 == 0){
                System.out.printf("%2s %7d %1s\n","  " , num2 , "*");
            }
            else {
                System.out.printf("%2s %7d\n", "  ",  num2);
                total += num2;
            }
            num = num/2; //integer division
            num2 += num2;
        }
        System.out.println("=================");
        //total += num2;
        System.out.printf("%17d",total);
    }
    public static void chal6(){
        System.out.println("? ");
        Scanner input21 = new Scanner(System.in);
        System.out.println("Num of games: ");
        int numGames = input21.nextInt();
        int game[][] = new int[numGames][3];
        for (int i = 0; i<numGames;i++) {
            //System.out.println("1 - Num of players\n2 - Start num\n3 - Stop num");
            for (int j = 0; j<3; j++) {
                Scanner input22 = new Scanner(System.in);
                switch (j){
                    case 0:
                        System.out.println("Num of players: ");
                        break;
                    case 1:
                        System.out.println("Start num: ");
                        break;
                    case 2:
                        System.out.println("End num: ");
                        break;
                }
                game[i][j] = input22.nextInt(); //player, start, stop
                //Scanner input23 = new Scanner(System.in);
                //int start = input23.nextInt();
                //Scanner input24 = new Scanner(System.in);
                //int stop = input24.nextInt();
            }
        }
        for (int i = 0; i<numGames; i++) {
            int player = game[i][0];
            int start = game[i][1];
            int stop = game[i][2];

            System.out.println("\nGame: " + (i+1) + " Players: " + player + " Start: " + start + " Stop: " + stop+"\n");

            int num = start;
            boolean print = true;
            boolean reverse = false;
            int actplayer = 1;

            while (num <= stop) {
                System.out.print("Player " + actplayer + ": ");
                int check5 = countNum(num, '5');
                if (five(num)) {
                    System.out.print("Fuzz ");
                    print = false;
                    reverse = !reverse;
                }
                if (seven(num)) {
                    System.out.print("Buzz ");
                    print = false;
                    reverse = !reverse;
                }
                while (check5 > 0) {
                    System.out.print("Fuzz ");
                    check5 -= 1;
                    print = false;
                    reverse = !reverse;
                }
                if (print) {
                    System.out.println(num);
                } else {
                    System.out.println("");
                }
                num += 1;
                print = true;
                if (reverse == false) {
                    actplayer++;
                } else {
                    actplayer--;
                    //reverse = !reverse;
                }
                if (actplayer > player) {
                    actplayer = 1;
                }
                if (actplayer == 0) {
                    actplayer = player;
                }
                //System.out.println(actplayer);
            }
        }
    }
    public static double popGet(int people){
        if (people < 21){
            double pop = java.lang.Math.ceil(people/7);
            return pop;
        }
        else{
            double pop = java.lang.Math.ceil(people/9);
            return pop;
        }
    }
    public static boolean five(int num) {
        boolean total = false;
        if (num % 5 == 0) {
            total = true;
        }
        return total;
    }
    public static boolean seven(int num) {
        boolean total = false;
        if (num % 7 == 0) {
            total = true;
        }
        return total;
    }
    public static int countNum(int num, char check){
        int countnumber=0;
        String str1 = Integer.toString(num);
        for(int i = 0; i < str1.length(); i++){
            if (str1.charAt(i) == check) {
                countnumber++;
            }
        }
        return countnumber;
    }

}
