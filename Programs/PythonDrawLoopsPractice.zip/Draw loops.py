from turtle import *
import random

def spirall():
    speed(0)
    for i in range (360):
        forward(i/4)
        right(25)

def spiral():
    speed(0)
    for i in range (360):
        forward(i)
        right(i)
def coolspriral():
    speed(0)
    side = 1
    r = random.uniform(0,1)
    g = random.uniform(0,1)
    b = random.uniform(0,1)
    for i in range (360):
        pencolor(r,g,b)
        forward(side)
        right(100)
        side=side+1
        r = random.uniform(0,1)
        g = random.uniform(0,1)
        b = random.uniform(0,1)
coolspriral()
