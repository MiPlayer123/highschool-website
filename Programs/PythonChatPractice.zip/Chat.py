print("What is your name? ")
firstname = input()
print ("What is your last name?")
lastname = input()
print("Hello", firstname, lastname)
if firstname == "Mikul" or firstname == "mikul" or firstname == "Askar" or firstname == "askari":
    print("I known you")
    if firstname == "Mikul" or firstname == "mikul":
        print("U want to login?")
        lol = input()
        if lol == "y":
            print("Password:")
            password = input()
            if password == "lolyeet":
                print ("Your in")
else:
    print("So your new")
print("Ok, what is your favorite food?")
food = input()

