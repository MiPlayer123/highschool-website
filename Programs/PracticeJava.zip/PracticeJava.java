import java.applet.Applet;
import java.awt.Graphics;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        /*
        Scanner input = new Scanner(System.in);
        System.out.println("Amount: ");
        int coin = input.nextInt();
        int quarters = coin/25;
        coin -= 25*quarters;
        int dimes = coin/10;
        coin -= dimes*10;
        int nickels = coin/5;
        coin -= 5*nickels;
        int pennies = coin;
        System.out.println("Quarters: " + quarters + " Dimes: " + dimes + " Nickels: " + nickels + " Pennies: " + pennies);
        */

        /*
        String[] math = {"Algebra 2H", "Dr. Hinde"};
        String[] english = {"English 9", "Ms. Applebaum"};
        String[] science = {"Bio 1H", "Mr. Greene"};
        String[] pref = {"Concert Band", "Mr. Horigan"};
        String[] compsci = {"Intro CompSci", "Dr. Reynolds"};
        String[] spanish = {"Spanisgh II", "Sr. Bowdy"};
        String[] worldciv = {"Worldviews", "Ms. Turlay Turlay"};

        System.out.println("1. "+ math[0] + "    | "+ math[1]);
        System.out.println("2. "+ english[0] + "     | "+ math[1]);
        System.out.println("3. "+ science[0] + "        | "+ science[1]);
        System.out.println("4. "+ pref[0] + "  | "+pref[1]);
        System.out.println("6. "+ compsci[0] + " | " + compsci[1]);
        System.out.println("7. "+ spanish[0] + "   | " + spanish[1]);
        System.out.println("8. "+ worldciv[0] + "    | " + worldciv[1]);
        */
        /*
        Scanner a = new Scanner(System.in);
        System.out.println("One number: ");
        Double a1 = a.nextDouble();
        Scanner b = new Scanner(System.in);
        System.out.println("Another number: ");
        Double b1 = b.nextDouble();

        double Add = add(a1,b1);
        double Sub = sub(a1,b1);
        double Mult = mult(a1,b1);
        double Div = div(a1,b1);
        double Circ = circ(a1,b1);
        System.out.println("Sum: " + Add);
        System.out.println("Difference: " + Sub);
        System.out.println("Product: " + Mult);
        System.out.println("Division: " + Div);
        System.out.println("Circumference: " + Circ);
         */
        /*
        Scanner input = new Scanner(System.in);
        System.out.println("Math Grade: ");
        int mGrade = input.nextInt();
        Scanner input2 = new Scanner(System.in);
        System.out.println("Science Grade: ");
        int sGrade = input2.nextInt();
        Scanner input3 = new Scanner(System.in);
        System.out.println("English Grade: ");
        int eGrade = input3.nextInt();
        Scanner input4 = new Scanner(System.in);
        System.out.println("Worldviews Grade: ");
        int wGrade = input4.nextInt();
        Scanner input5 = new Scanner(System.in);
        System.out.println("Language Grade: ");
        int lGrade = input5.nextInt();
        Scanner input6 = new Scanner(System.in);
        System.out.println("Art Grade: ");
        int aGrade = input6.nextInt();

        double mGradeF = (0.06666) * mGrade -2.3333;
        //mGradeF = java.lang.Math.round(mGradeF);
        double sGradeF = (0.06666) * sGrade -2.3333;
        //sGradeF = java.lang.Math.round(sGradeF);
        double eGradeF = (0.06666) * eGrade - 2.3333;
        //eGradeF = java.lang.Math.round(eGradeF);
        double wGradeF = (0.06666) * wGrade -2.3333;
        //wGradeF = java.lang.Math.round(wGradeF);
        double lGradeF = (0.06666) * lGrade -2.3333;
        //lGradeF = java.lang.Math.round(lGradeF);
        double aGradeF = (0.06666) * aGrade -2.3333;
        //aGradeF = java.lang.Math.round(aGradeF);

        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println("Math GPA: " + df.format(mGradeF));
        System.out.println("Science GPA: " + df.format(sGradeF));
        System.out.println("Woldviews GPA: " + df.format(wGradeF));
        System.out.println("English GPA: " + df.format(eGradeF));
        System.out.println("Language GPA: " + df.format(lGradeF));
        System.out.println("PA GPA: " + df.format(aGradeF));
        double gpa = (mGradeF + eGradeF + lGradeF + wGradeF+ sGradeF + aGradeF)/6;
        System.out.println(" ");
        System.out.println("Overall GPA: " + df.format(gpa));
        if (gpa == 4){
            System.out.println("You are good.");
        }
        else{
            System.out.println("You are bad.");
        }
         */
            Scanner height1 = new Scanner(System.in);
            System.out.println("Height in inches: ");
            double height = height1.nextInt();
        Scanner weight1 = new Scanner(System.in);
        System.out.println("Weight in pounds: ");
        double weight = weight1.nextInt();
        double bmi = (weight/(height*height)) * 703;
        System.out.println("BMI: "+ bmi);
        if(bmi < 18.5){
            System.out.println("You are underweight");
        }
        else if (bmi >= 18.5 && bmi < 25){
            System.out.println("You are normal");
        }
        else if (bmi >= 25 && bmi < 30){
            System.out.println("You are overweight");
        }
        else{
            System.out.println("You are obese");
        }
    }
    public static double add (double a , double b){
        double total = a+b;
        return total;
    }
    public static double sub (double a , double b){
        double total = a-b;
        return total;
    }
    public static double mult (double a , double b){
        double total = a*b;
        return total;
    }
    public static double div (double a , double b){
        double total = a/b;
        return total;
    }
    public static double circ (double a , double b) {
        double total = 2 * a * 3.1415;
        return total;
    }

}
