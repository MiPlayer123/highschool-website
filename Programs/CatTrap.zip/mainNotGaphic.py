import math
import random

# x,y,blocked,cat on
field = [[-2, 0, False, False], [-2, 1, False, False], [-2, 2, False, False],
         [-1, -1, False, False], [-1, 0, False, False], [-1, 1, False, False], [-1, 2, False, False],
         [0, -2, False, False], [0, -1, False, False], [0, 0, False, False], [0, 1, False, False], [0, 2, False, False],
         [1, -2, False, False], [1, -1, False, False], [1, 0, False, False], [1, 1, False, False],
         [2, -2, False, False], [2, -1, False, False], [2, 0, False, False]]

catPos = [0,0]

inpCoord = list()
inpCoord = [0, 0]
global inpVal
inpVal = 1
checkVal = 0
catVal = 9

"""
cat = x
blocked = 0
open = O

   0 0 0
  0 0 0 0
0 0 0 0 0 0
  0 0 0 0
   0 0 0
"""

def printInField(val):
    if field[val][2]:
        print("0", end="  ")
    elif field[val][3]:
        print("X", end="  ")
    else:
        print("O", end="  ")
def printField():
    for i in range (19):
        #print(end="   ")
        #printField(i)
        if i == 0:
            print(end = "   ")
        elif i == 3:
            print(end = " ")
        elif i == 12:
            print(end = "  ")
        elif i == 16:
            print(end = "   ")
        printInField(i)
        if i==2:
            print(" ")
        elif i==6:
            print(" ")
        elif i==11:
            print(" ")
        elif i==15:
            print(" ")
    print(" ")

def getNum(inpCoord, catPos):
    checkVal = 0
    global inpVal
    global catVal
    for i in range (0,20):
        checkVal+=1
        if field[i][0,1] == catPos:
            catVal = checkVal
        if field[i][0,1] == inpCoord:
            inpVal = checkVal

def blockFiled(inpVal):
    field[inpVal-1][2] = True

field[catVal][3] = True
while True:
    printField()
    print(inpVal, inpCoord)
    inpVal  = int(input("Pos: "))
    #getNum(inpCoord, checkVal)
    blockFiled(inpVal)